/* Farm Stock Book — data store.
   Local-first: every record is saved on the phone straight away, then synced to
   Supabase when there is signal. Works with no signal in the field.
   Without a Supabase config it runs in "demo" mode: everything stays on this device. */
(function () {
  "use strict";
  const KEY = "fsb-docs-v1:", OUT = "fsb-outbox-v1:";
  let docs = new Map();          // "coll/id" -> { coll, id, data }
  let outbox = [];               // pending writes: { coll, id, data|null }
  const listeners = new Set();
  let farmId = null, sb = null, channel = null, flushing = false, pullTimer = null;
  const statusFns = new Set();

  const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const split = (path) => { const p = String(path).split("/"); return [p[0], p.slice(1).join("/")]; };

  function load() {
    try {
      const d = JSON.parse(localStorage.getItem(KEY + farmId) || "[]");
      docs = new Map(d.map((x) => [x.coll + "/" + x.id, x]));
      outbox = JSON.parse(localStorage.getItem(OUT + farmId) || "[]");
    } catch (e) { console.warn("Store load failed", e); }
  }
  let saveTimer;
  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        localStorage.setItem(KEY + farmId, JSON.stringify([...docs.values()]));
        localStorage.setItem(OUT + farmId, JSON.stringify(outbox));
      } catch (e) { console.warn("Store save failed", e); }
    }, 40);
  }
  let notifyQueued = false;
  function notify() {
    if (notifyQueued) return; notifyQueued = true;
    queueMicrotask(() => { notifyQueued = false; listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } }); });
  }
  function status() { const s = Store.state(); statusFns.forEach((fn) => { try { fn(s); } catch (e) {} }); }

  function applyLocal(coll, id, data) {
    const k = coll + "/" + id;
    if (data === null) docs.delete(k); else docs.set(k, { coll, id, data });
    persist(); notify();
  }
  function write(coll, id, data) {
    applyLocal(coll, id, data);
    if (!sb) return Promise.resolve();
    outbox = outbox.filter((o) => !(o.coll === coll && o.id === id));
    outbox.push({ coll, id, data });
    persist(); status(); flush();
    return Promise.resolve();
  }

  async function flush() {
    if (!sb || flushing || !navigator.onLine) return;
    flushing = true;
    try {
      while (outbox.length) {
        const op = outbox[0];
        const r = op.data === null
          ? await sb.from("docs").delete().match({ farm_id: farmId, coll: op.coll, id: op.id })
          : await sb.from("docs").upsert({ farm_id: farmId, coll: op.coll, id: op.id, data: op.data, updated_at: new Date().toISOString() });
        if (r.error) { console.warn("Sync error", r.error); break; }
        outbox.shift(); persist();
      }
    } catch (e) { console.warn("Sync failed", e); }
    finally { flushing = false; status(); }
  }

  async function pull() {
    if (!sb || !navigator.onLine) return;
    const rows = [];
    for (let from = 0; ; from += 1000) {
      const { data, error } = await sb.from("docs").select("coll,id,data").eq("farm_id", farmId).range(from, from + 999);
      if (error) { console.warn("Pull failed", error); return; }
      rows.push(...data); if (data.length < 1000) break;
    }
    const pending = new Set(outbox.map((o) => o.coll + "/" + o.id)), seen = new Set();
    rows.forEach((r) => { const k = r.coll + "/" + r.id; seen.add(k); if (!pending.has(k)) docs.set(k, { coll: r.coll, id: r.id, data: r.data }); });
    [...docs.keys()].forEach((k) => { if (!seen.has(k) && !pending.has(k)) docs.delete(k); });
    persist(); notify(); status();
  }

  function subscribeRealtime() {
    if (!sb) return;
    if (channel) sb.removeChannel(channel);
    channel = sb.channel("farm-" + farmId)
      .on("postgres_changes", { event: "*", schema: "public", table: "docs", filter: "farm_id=eq." + farmId }, (p) => {
        const row = p.eventType === "DELETE" ? p.old : p.new;
        if (!row || !row.coll) return;
        if (outbox.some((o) => o.coll === row.coll && o.id === row.id)) return; // our own newer write wins
        applyLocal(row.coll, row.id, p.eventType === "DELETE" ? null : row.data);
      })
      .subscribe();
  }

  /* ---- Firestore-style API used by the app ---- */
  const snapDoc = (coll, id) => { const d = docs.get(coll + "/" + id); return { id, exists: !!d, data: () => (d ? d.data : undefined) }; };
  function query(coll, opts) {
    const q = {
      orderBy: (field, dir) => query(coll, { ...opts, field, dir: dir || "asc" }),
      limit: (n) => query(coll, { ...opts, n }),
      where: () => q,
      get: async () => run(),
      onSnapshot(next) {
        const fn = () => next(run());
        listeners.add(fn); queueMicrotask(fn);
        return () => listeners.delete(fn);
      },
    };
    function run() {
      let list = [...docs.values()].filter((d) => d.coll === coll);
      if (opts.field) {
        const f = opts.field, s = opts.dir === "desc" ? -1 : 1;
        list.sort((a, b) => String(a.data[f] ?? "").localeCompare(String(b.data[f] ?? "")) * s);
      }
      if (opts.n) list = list.slice(0, opts.n);
      const out = list.map((d) => ({ id: d.id, exists: true, data: () => d.data }));
      return { docs: out, size: out.length, empty: !out.length };
    }
    return q;
  }
  function docRef(coll, id) {
    return {
      id, path: coll + "/" + id,
      get: async () => snapDoc(coll, id),
      set: (data) => write(coll, id, JSON.parse(JSON.stringify(data))),
      update: (data) => {
        const cur = docs.get(coll + "/" + id);
        if (!cur) return Promise.reject({ code: "invalid_argument", message: "Document does not exist" });
        return write(coll, id, { ...cur.data, ...JSON.parse(JSON.stringify(data)) });
      },
      delete: () => write(coll, id, null),
      onSnapshot(next) {
        const fn = () => next(snapDoc(coll, id));
        listeners.add(fn); queueMicrotask(fn);
        return () => listeners.delete(fn);
      },
    };
  }
  const db = {
    collection(path) {
      const coll = path;
      return Object.assign(query(coll, {}), {
        path: coll,
        doc: (id) => docRef(coll, id || newId()),
        add: async (data) => { const id = newId(); await write(coll, id, JSON.parse(JSON.stringify(data))); return docRef(coll, id); },
      });
    },
    doc(path) { const [c, i] = split(path); return docRef(c, i); },
  };

  const Store = {
    db,
    get client() { return sb; },
    get farmId() { return farmId; },
    get demo() { return !sb; },
    state: () => ({ online: navigator.onLine, pending: outbox.length, demo: !sb }),
    onStatus: (fn) => { statusFns.add(fn); fn(Store.state()); },
    async open(id, client) {
      farmId = id; sb = client || null; load(); notify();
      if (sb) {
        subscribeRealtime(); await pull(); flush();
        clearInterval(pullTimer); pullTimer = setInterval(() => { flush(); }, 30000);
      }
      status();
      return db;
    },
    async syncNow() { await flush(); await pull(); },
    exportAll: () => [...docs.values()],
    async importAll(list) { for (const d of list) await write(d.coll, d.id, d.data); },
  };
  window.addEventListener("online", () => { status(); Store.syncNow(); });
  window.addEventListener("offline", status);
  window.Store = Store;
})();
