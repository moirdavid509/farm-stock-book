/* Farm Stock Book — platform services: login, farm codes, photo reading,
   weather, GPS and file saving. Everything Claude used to provide. */
(function () {
  "use strict";
  const C = window.FSB_CONFIG || {};
  const hasCloud = !!(C.supabaseUrl && C.supabaseAnonKey && window.supabase);
  const sb = hasCloud ? window.supabase.createClient(C.supabaseUrl, C.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true } }) : null;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let farm = null; // { id, name, join_code, role }

  /* ---------------- login + farm gate ---------------- */
  function gate(html) {
    let g = $("#gate");
    if (!g) { g = document.createElement("div"); g.id = "gate"; document.body.appendChild(g); }
    g.innerHTML = `<div class="gate-in stack"><h1 style="font-size:32px">🌾 ${esc(C.appName || "Farm Stock Book")}</h1>${html}</div>`;
    g.hidden = false; return g;
  }
  function closeGate() { const g = $("#gate"); if (g) g.hidden = true; }
  const say = (t) => { try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t); u.lang = "en-GB"; u.rate = 0.9; speechSynthesis.speak(u); } catch (e) {} };
  const spk = (t) => `<button class="spk" type="button" data-say="${esc(t)}" aria-label="Read out loud">🔊</button>`;

  /* ---------------- PIN pad (big buttons, read aloud) ---------------- */
  // Shows a 4-number pad inside `host`. Resolves with the PIN, or null if Back is pressed.
  function pinPad(host, title, sub, opts = {}) {
    return new Promise((resolve) => {
      let pin = "";
      host.innerHTML = `<div class="stack pinwrap">
        <div class="hrow"><p class="wz-q" style="margin:0">${esc(title)}</p>${spk(title + ". " + (sub || ""))}</div>
        ${sub ? `<p style="margin:0">${esc(sub)}</p>` : ""}
        <div class="pindots" aria-live="polite">${[0, 1, 2, 3].map((i) => `<span data-d="${i}"></span>`).join("")}</div>
        <div class="pinmsg" id="pinMsg" role="alert">${esc(opts.msg || "")}</div>
        <div class="pinpad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button type="button" data-n="${n}">${n}</button>`).join("")}
          <button type="button" data-k="back" aria-label="Back">${opts.noBack ? "" : "←"}</button><button type="button" data-n="0">0</button><button type="button" data-k="del" aria-label="Delete">⌫</button></div>
        ${opts.extra || ""}</div>`;
      const dots = () => host.querySelectorAll(".pindots span").forEach((s, i) => s.classList.toggle("on", i < pin.length));
      const done = (v) => { document.removeEventListener("keydown", key); resolve(v); };
      const press = (n) => { if (pin.length >= 4) return; pin += n; dots(); if (pin.length === 4) setTimeout(() => done(pin), 150); };
      host.querySelectorAll("[data-n]").forEach((b) => (b.onclick = () => press(b.dataset.n)));
      host.querySelector("[data-k=del]").onclick = () => { pin = pin.slice(0, -1); dots(); };
      host.querySelector("[data-k=back]").onclick = () => { if (!opts.noBack) done(null); };
      const key = (e) => { if (/^[0-9]$/.test(e.key)) press(e.key); else if (e.key === "Backspace") { pin = pin.slice(0, -1); dots(); } };
      document.addEventListener("keydown", key);
      if (opts.msg && opts.sayMsg) say(opts.msg);
    });
  }
  const shake = (host) => { const d = host.querySelector(".pindots"); if (d) { d.classList.remove("shake"); void d.offsetWidth; d.classList.add("shake"); } try { navigator.vibrate && navigator.vibrate(200); } catch (e) {} };

  // Same rules as the database: no 0000, 1111, 1234, 4321, 1212, 2580...
  function pinIsOk(p) {
    if (!/^[0-9]{4}$/.test(p)) return false;
    if (["1212","2580","0852","1122","1313","6969","1004","2000","1010","2020","2121","1001","0101"].includes(p)) return false;
    const d = p.split("").map(Number);
    if (d.every((x) => x === d[0])) return false;
    const up = d.every((x, i) => i === 0 || x === (d[i - 1] + 1) % 10), down = d.every((x, i) => i === 0 || x === (d[i - 1] + 9) % 10);
    return !(up || down);
  }
  /* ---------------- talking to the pin-auth server function ---------------- */
  async function fn(action, body = {}) {
    if (!navigator.onLine) return { error: "offline" };
    try {
      const { data, error } = await sb.functions.invoke("pin-auth", { body: { action, ...body } });
      if (error) { try { return await error.context.json(); } catch (e) { return { error: "server" }; } }
      return data || { error: "server" };
    } catch (e) { return { error: "offline" }; }
  }
  const WORDS = {
    offline: "No signal. You need signal to log in the first time on a phone.",
    no_farm: "That farm code didn't work. Check it with the farmer.",
    slow_down: "Too many wrong tries from this phone. Wait an hour, then try again.",
    locked: "Locked for 15 minutes after 5 wrong tries. If you've forgotten your PIN, ask the farmer to reset it.",
    blocked: "Your PIN is locked. Ask the farmer to give you a new PIN.",
    weak_pin: "That PIN is too easy to guess (like 1234 or 1111). Pick a different one.",
    signup_code: "That sign-up code isn't right.",
    session_expired: "Please log in again.",
    owner_only: "Only the farm owner can do that.",
    same_name: "There's already someone with that name. Add a surname or initial.",
    not_self: "You can't remove yourself.",
    server: "Something went wrong. Try again in a minute.",
  };
  const words = (r) => r.error === "wrong" ? `Wrong PIN. ${r.left} ${r.left === 1 ? "try" : "tries"} left before it locks.` : WORDS[r.error] || WORDS.server;

  /* ---------------- login: farm code → your name → PIN ---------------- */
  async function login() {
    while (true) {
      let code = localStorage.getItem("fsb-code");
      if (!code) {
        const r = await askFarmCode();
        if (r === "new") { const s = await newFarm(); if (s) return s; continue; }
        code = r;
      }
      const res = await fn("people", { code });
      if (res.error) { if (res.error === "no_farm") localStorage.removeItem("fsb-code"); await notice(words(res)); continue; }
      localStorage.setItem("fsb-code", code);
      const person = await pickPerson(res);
      if (person === "change") { localStorage.removeItem("fsb-code"); continue; }
      let msg = "";
      while (true) {
        const g = gate("");
        const pin = await pinPad(g.querySelector(".gate-in"), `Hello ${person.name}`, "Type your 4-number PIN.", { msg, sayMsg: !!msg });
        if (pin === null) break;
        const r = await fn("login", { code, userId: person.id, pin });
        if (r.session) { await sb.auth.setSession(r.session); return r.farm; }
        msg = words(r); shake(g);
        if (r.error === "locked" || r.error === "blocked" || r.error === "slow_down") { await notice(msg); break; }
      }
    }
  }
  function notice(text) {
    return new Promise((res) => {
      gate(`<div class="hrow"><p class="wz-q" style="margin:0">⚠️ ${esc(text)}</p>${spk(text)}</div><button class="big primary" id="gOk" type="button">OK</button>`);
      say(text); $("#gOk").onclick = () => res();
    });
  }
  function askFarmCode(msg) {
    return new Promise((res) => {
      gate(`<div class="hrow"><p class="wz-q" style="margin:0">Type your farm code</p>${spk("Type your farm code. It has 6 letters and numbers. The farmer can find it in Settings.")}</div>
        <p style="margin:0">6 letters and numbers. The farmer can find it in Settings.</p>
        <input id="gCode" maxlength="9" autocomplete="off" autocapitalize="characters" spellcheck="false" style="font-size:34px;text-align:center;letter-spacing:.25em;text-transform:uppercase;font-family:var(--display)">
        ${msg ? `<div class="banner">${esc(msg)}</div>` : ""}
        <button class="big primary" id="gNext" type="button">Next →</button>
        <hr style="border:0;border-top:1px solid var(--line);width:100%">
        <button class="big ghost" id="gNew" type="button">🌾 Setting up a new farm? Start here</button>`);
      const go = () => { const c = $("#gCode").value.toUpperCase().replace(/[^A-Z0-9]/g, ""); if (c.length < 6) { say("Please type all 6 letters and numbers."); return; } res(c); };
      $("#gNext").onclick = go; $("#gCode").onkeydown = (e) => { if (e.key === "Enter") go(); };
      $("#gNew").onclick = () => res("new"); setTimeout(() => $("#gCode") && $("#gCode").focus(), 50);
    });
  }
  function pickPerson(res) {
    return new Promise((resolve) => {
      gate(`<div class="hrow"><p class="wz-q" style="margin:0">Who are you?</p>${spk("Who are you? Tap your name.")}</div>
        <p style="margin:0">🌾 ${esc(res.farm.name)}</p>
        <div class="choices">${res.people.map((p, i) => `<button type="button" data-i="${i}" style="min-height:76px;font-size:22px">${esc(p.name)}</button>`).join("")}</div>
        <p class="hint">Not on the list? Ask the farmer to add you.</p>
        <button class="big ghost" id="gChange" type="button">Wrong farm? Type a different code</button>`);
      document.querySelectorAll("#gate [data-i]").forEach((b) => (b.onclick = () => resolve(res.people[+b.dataset.i])));
      $("#gChange").onclick = () => resolve("change");
    });
  }
  async function choosePin(host, who) {
    let msg = "";
    while (true) {
      const a = await pinPad(host, who ? `Pick a 4-number PIN for ${who}` : "Pick your 4-number PIN", "Something you'll remember. Not 1234 or 1111.", { msg, sayMsg: !!msg });
      if (a === null) return null;
      if (!pinIsOk(a)) { msg = WORDS.weak_pin; shake(host); continue; }
      const b = await pinPad(host, "Type the same PIN again", "To make sure it's right.");
      if (b === null) return null;
      if (a === b) return a;
      msg = "The two PINs didn't match. Try again.";
    }
  }
  async function newFarm() {
    const ask = (q, ph, extra) => new Promise((res) => {
      gate(`<div class="hrow"><p class="wz-q" style="margin:0">${esc(q)}</p>${spk(q)}</div><input id="gIn" placeholder="${esc(ph)}" maxlength="40">${extra || ""}
        <button class="big primary" id="gNext" type="button">Next →</button><button class="big ghost" id="gBack" type="button">← Back</button>`);
      const go = () => { const v = $("#gIn").value.trim(); if (v) res(v); };
      $("#gNext").onclick = go; $("#gIn").onkeydown = (e) => { if (e.key === "Enter") go(); }; $("#gBack").onclick = () => res(null);
      setTimeout(() => { const i = $("#gIn"); if (i) i.focus(); }, 50);
    });
    const farmName = await ask("What is the farm called?", "e.g. Lyne of Urchany"); if (!farmName) return null;
    const name = await ask("What is your name?", "e.g. David"); if (!name) return null;
    const g = gate("");
    const pin = await choosePin(g.querySelector(".gate-in")); if (!pin) return null;
    let signupCode = "";
    while (true) {
      gate(`<p>Setting up ${esc(farmName)}…</p>`);
      const r = await fn("create_farm", { farmName, name, pin, signupCode });
      if (r.session) {
        await sb.auth.setSession(r.session); localStorage.setItem("fsb-code", r.farm.join_code);
        await notice(`Your farm is ready. Your farm code is ${r.farm.join_code.split("").join(" ")}. Workers type this code on their phone. You can find it again in Settings.`);
        return r.farm;
      }
      if (r.error === "signup_code") { signupCode = await ask(signupCode ? "That sign-up code wasn't right. Try again." : "Type your sign-up code", "From the app provider"); if (!signupCode) return null; continue; }
      await notice(words(r)); return null;
    }
  }

  async function myFarm(session) {
    const { data, error } = await sb.from("members").select("role, display_name, farms(id, name, join_code)").eq("user_id", session.user.id).eq("active", true).maybeSingle();
    if (error) throw error;
    return data && data.farms ? { ...data.farms, role: data.role, me: data.display_name } : null;
  }

  async function start() {
    if (!hasCloud) {
      farm = { id: "demo", name: "Demo farm", join_code: "", role: "owner", me: "" };
      const db = await window.Store.open("demo", null);
      closeGate(); return db;
    }
    let { data: { session } } = await sb.auth.getSession();
    if (session) {
      try { farm = await myFarm(session); } catch (e) { farm = JSON.parse(localStorage.getItem("fsb-farm-info") || "null"); } // offline: use the saved copy
      if (!farm) { await sb.auth.signOut(); session = null; }
    }
    if (!session) { farm = await login(); }
    try { const { data: { session: s2 } } = await sb.auth.getSession(); if (s2) farm.uid = s2.user.id; } catch (e) {}
    localStorage.setItem("fsb-farm-info", JSON.stringify(farm));
    const db = await window.Store.open(farm.id, sb);
    if (site.on) await site.lock(); else closeGate();
    return db;
  }
  // Switch person: keep the farm code, go back to the list of names.
  async function switchPerson() { if (sb) await sb.auth.signOut(); localStorage.removeItem("fsb-farm-info"); location.reload(); }
  // Leave this farm on this phone completely.
  async function signOut() { if (sb) await sb.auth.signOut(); ["fsb-code", "fsb-farm-info", "fsb-site", "fsb-site-people"].forEach((k) => localStorage.removeItem(k)); location.reload(); }

  /* ---------------- Site tablet mode ----------------
     A tablet kept on the farm, shared by everyone. It stays logged in to the farm,
     but each person unlocks it with their own name + PIN, and it locks itself after
     a few minutes of no use. PINs are checked by the server when there's signal;
     with no signal they're checked against a scrambled copy kept on the tablet
     (made the first time each person unlocks it with signal). */
  const SITE = "fsb-site", SITEP = "fsb-site-people";
  const sget = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const sset = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  let person = null, lastActive = Date.now(), lockHooks = [], pauseFns = [], locking = false;
  const enc = new TextEncoder();
  const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
  async function pinHash(pin, saltB64) {
    const key = await crypto.subtle.importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
    const salt = Uint8Array.from(atob(saltB64), (c) => c.charCodeAt(0));
    return b64(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: 210000 }, key, 256));
  }
  async function remember(p, pin) {
    const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
    const all = sget(SITEP, {});
    all[p.id] = { name: p.name, role: p.role, pinSetAt: (all[p.id] || {}).pinSetAt || "", salt, hash: await pinHash(pin, salt), fails: 0, lockedUntil: 0 };
    sset(SITEP, all);
  }
  async function checkOffline(id, pin) {
    const all = sget(SITEP, {}), c = all[id];
    if (!c || !c.hash) return { error: "no_offline" };
    if (c.lockedUntil === -1) return { error: "blocked" };
    if (c.lockedUntil > Date.now()) return { error: "locked" };
    if ((await pinHash(pin, c.salt)) === c.hash) { c.fails = 0; c.lockedUntil = 0; sset(SITEP, all); return { ok: true, person: { id, name: c.name, role: c.role } }; }
    c.fails = (c.fails || 0) + 1;
    if (c.fails >= 10) c.lockedUntil = -1; else if (c.fails % 5 === 0) c.lockedUntil = Date.now() + 15 * 60e3;
    sset(SITEP, all);
    if (c.lockedUntil === -1) return { error: "blocked" };
    if (c.lockedUntil > Date.now()) return { error: "locked" };
    return { error: "wrong", left: 5 - (c.fails % 5) };
  }
  async function sitePeople() {
    const cached = sget(SITEP, {});
    if (navigator.onLine) {
      const r = await fn("list_people");
      if (r.people) {
        // Forget anyone the farmer has removed; keep everyone else's offline copy.
        const keep = {};
        r.people.forEach((p) => {
          let c = { ...(cached[p.id] || {}), name: p.name, role: p.role };
          // PIN changed or reset since this tablet stored it: forget the old one.
          if (c.hash && c.pinSetAt !== (p.pinSetAt || "")) c = { name: p.name, role: p.role };
          c.pinSetAt = p.pinSetAt || "";
          keep[p.id] = c;
        });
        sset(SITEP, keep);
        return r.people.map((p) => ({ id: p.id, name: p.name, role: p.role, offline: !!(keep[p.id] && keep[p.id].hash) }));
      }
    }
    return Object.entries(cached).map(([id, c]) => ({ id, name: c.name, role: c.role, offline: !!c.hash }));
  }
  async function unlockScreen(msgFirst) {
    while (true) {
      const ppl = await sitePeople();
      const pick = await new Promise((resolve) => {
        gate(`<div class="hrow"><p class="wz-q" style="margin:0">Who are you?</p>${spk("Who are you? Tap your name, then type your PIN.")}</div>
          <p style="margin:0">🌾 ${esc(farm.name)} · Site tablet${navigator.onLine ? "" : " · 📴 No signal"}</p>
          ${msgFirst ? `<div class="banner">${esc(msgFirst)}</div>` : ""}
          <div class="choices site-names">${ppl.map((p, i) => `<button type="button" data-i="${i}">${esc(p.name)}</button>`).join("") || "<p>No people yet. The farmer adds people in Settings.</p>"}</div>
          <p class="hint">Not on the list? Ask the farmer to add you.</p>`);
        document.querySelectorAll("#gate [data-i]").forEach((b) => (b.onclick = () => resolve(ppl[+b.dataset.i])));
      });
      msgFirst = "";
      let msg = "";
      while (true) {
        const g = gate("");
        const pin = await pinPad(g.querySelector(".gate-in"), `Hello ${pick.name}`, "Type your PIN to unlock.", { msg, sayMsg: !!msg });
        if (pin === null) break;
        let r;
        if (navigator.onLine) {
          r = await fn("verify_pin", { userId: pick.id, pin });
          if (r.ok) await remember(r.person, pin);
          if (r.error === "offline") r = await checkOffline(pick.id, pin);
        } else r = await checkOffline(pick.id, pin);
        if (r.ok) { person = r.person; lastActive = Date.now(); closeGate(); return person; }
        if (r.error === "no_offline") { msg = "No signal, and this tablet doesn't have your current PIN yet. Unlock it once where there's signal."; shake(g); continue; }
        msg = words(r); shake(g);
        if (["locked", "blocked", "slow_down"].includes(r.error)) { await notice(msg); break; }
      }
    }
  }
  const site = {
    get on() { return hasCloud && !!sget(SITE, {}).on; },
    get minutes() { return sget(SITE, {}).minutes || 5; },
    get person() { return person; },
    enable(minutes) { sset(SITE, { on: true, minutes: minutes || 5 }); },
    setMinutes(m) { sset(SITE, { ...sget(SITE, {}), minutes: m }); },
    disable() { localStorage.removeItem(SITE); localStorage.removeItem(SITEP); person = null; },
    onLock(fn2) { lockHooks.push(fn2); },
    pauseWhile(fn2) { pauseFns.push(fn2); },
    async lock(msg) {
      if (locking) return; locking = true;
      person = null; lockHooks.forEach((h) => { try { h(); } catch (e) {} });
      try { await unlockScreen(msg); } finally { locking = false; }
      lockHooks.forEach((h) => { try { h(person); } catch (e) {} });
    },
  };
  ["pointerdown", "keydown", "touchstart", "scroll"].forEach((ev) => document.addEventListener(ev, () => { lastActive = Date.now(); }, { passive: true, capture: true }));
  setInterval(() => {
    if (!site.on || !person || locking) return;
    if (pauseFns.some((f) => { try { return f(); } catch (e) { return false; } })) { lastActive = Date.now(); return; }
    if (Date.now() - lastActive > site.minutes * 60e3) site.lock("Locked after " + site.minutes + " minutes with nobody using it.");
  }, 10e3);
  document.addEventListener("visibilitychange", () => { if (!document.hidden && site.on && person && !locking && Date.now() - lastActive > site.minutes * 60e3) site.lock(); });

  /* ---------------- people (farm owner) ---------------- */
  const people = {
    list: () => fn("list_people"),
    add: (name, pin, role) => fn("add_person", { name, pin, role }),
    async resetPin(userId, pin) { const r = await fn("reset_pin", { userId, pin }); if (r.ok && site.on) await sitePeople(); return r; },
    async remove(userId) { const r = await fn("remove_person", { userId }); if (r.ok && site.on) await sitePeople(); return r; },
    async changeMyPin(oldPin, newPin) {
      const r = await fn("change_pin", { oldPin, newPin, ...(site.on && person ? { userId: person.id } : {}) });
      if (r.ok && site.on && person) { await sitePeople(); await remember(person, newPin); } // keep the tablet's offline copy up to date
      return r;
    },
    newCode: async () => { const r = await fn("new_code"); if (r.code) { farm = { ...farm, join_code: r.code }; localStorage.setItem("fsb-code", r.code); localStorage.setItem("fsb-farm-info", JSON.stringify(farm)); } return r; },
    words, pinPad, choosePin, shake,
  };

  /* ---------------- photo reading (server function calls Claude API) ---------------- */
  async function shrink(file, max = 1600) {
    const img = await createImageBitmap(file);
    const k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.85).split(",")[1];
  }
  function parseJSON(text) {
    try { return JSON.parse(text); } catch (e) {}
    const f = text.match(/```(?:json)?\s*([\s\S]*?)```/); if (f) { try { return JSON.parse(f[1]); } catch (e) {} }
    const a = text.search(/[\[{]/), b = Math.max(text.lastIndexOf("}"), text.lastIndexOf("]"));
    if (a >= 0 && b > a) { try { return JSON.parse(text.slice(a, b + 1)); } catch (e) {} }
    throw { code: "invalid_json", text };
  }
  const ai = hasCloud ? {
    async json(prompt, opts = {}) {
      if (!navigator.onLine) throw { code: "offline" };
      const img = opts.images && opts.images[0];
      const body = { prompt, image: img ? await shrink(img) : null, mediaType: "image/jpeg" };
      const { data, error } = await sb.functions.invoke("scan", { body });
      if (error) {
        let code = "upstream_error", message = String(error.message || error);
        try { const b = await error.context.json(); code = b.code || code; message = b.error || message; } catch (e) {}
        throw { code, message };
      }
      if (data && data.error) throw { code: data.code || "upstream_error", message: data.error };
      return parseJSON(data.text || "");
    },
  } : null;

  /* ---------------- weather (Open-Meteo) ---------------- */
  const DIR16 = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  const deg2dir = (d) => DIR16[Math.round(((d % 360) + 360) % 360 / 22.5) % 16];
  const WMO = { 0: "Clear", 1: "Mostly clear", 2: "Partly cloudy", 3: "Cloudy", 45: "Fog", 48: "Freezing fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
    61: "Light rain", 63: "Rain", 65: "Heavy rain", 66: "Freezing rain", 67: "Freezing rain", 71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains",
    80: "Showers", 81: "Heavy showers", 82: "Violent showers", 85: "Snow showers", 86: "Snow showers", 95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with hail" };
  async function weather(lat, lng, place) {
    const base = C.openMeteoKey ? "https://customer-api.open-meteo.com/v1/forecast" : "https://api.open-meteo.com/v1/forecast";
    const q = new URLSearchParams({ latitude: lat, longitude: lng, timezone: "Europe/London", wind_speed_unit: "mph", forecast_days: "10",
      hourly: "temperature_2m,precipitation_probability,precipitation,wind_speed_10m,wind_gusts_10m,wind_direction_10m,relative_humidity_2m",
      daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant" });
    if (C.openMeteoKey) q.set("apikey", C.openMeteoKey);
    const r = await fetch(base + "?" + q); if (!r.ok) throw new Error("Weather " + r.status);
    const j = await r.json(), H = j.hourly, D = j.daily;
    return {
      updatedAt: new Date().toISOString(), place: place || "", source: "Open-Meteo",
      hours: H.time.map((t, i) => ({ t, temp: H.temperature_2m[i], rainProb: H.precipitation_probability[i] ?? 0, rain: H.precipitation[i], wind: H.wind_speed_10m[i],
        gust: H.wind_gusts_10m[i], rh: H.relative_humidity_2m[i], dir: deg2dir(H.wind_direction_10m[i]) })),
      days: D.time.map((d, i) => ({ date: d, tmax: D.temperature_2m_max[i], tmin: D.temperature_2m_min[i], rainProb: D.precipitation_probability_max[i] ?? 0,
        rainMm: D.precipitation_sum[i], wind: D.wind_speed_10m_max[i], gust: D.wind_gusts_10m_max[i], dir: deg2dir(D.wind_direction_10m_dominant[i]), summary: WMO[D.weather_code[i]] || "" })),
    };
  }

  /* ---------------- GPS ---------------- */
  const gps = {
    available: "geolocation" in navigator,
    here(opts) {
      return new Promise((res, rej) => {
        if (!gps.available) return rej({ code: "unavailable" });
        navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, t: p.timestamp }),
          (e) => rej({ code: e.code === 1 ? "denied" : "failed", message: e.message }), { enableHighAccuracy: true, timeout: 20000, maximumAge: 15000, ...(opts || {}) });
      });
    },
    watch(cb) {
      if (!gps.available) return () => {};
      const id = navigator.geolocation.watchPosition((p) => cb({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, t: p.timestamp }), () => {},
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 30000 });
      return () => navigator.geolocation.clearWatch(id);
    },
    dist(a, b) { // metres
      const R = 6371000, r = Math.PI / 180, dLat = (b.lat - a.lat) * r, dLng = (b.lng - a.lng) * r;
      const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLng / 2) ** 2;
      return 2 * R * Math.asin(Math.sqrt(x));
    },
  };

  /* ---------------- files ---------------- */
  async function saveFile(name, data, mime) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
    const file = new File([blob], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android|iPhone|iPad/i.test(navigator.userAgent)) {
      try { await navigator.share({ files: [file], title: name }); return "shared"; } catch (e) { if (e.name === "AbortError") throw { code: "declined" }; }
    }
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    return "saved";
  }

  const current = () => (site.on && person ? person : farm ? { id: farm.uid, name: farm.me, role: farm.role } : null);
  window.Platform = { start, signOut, switchPerson, people, site, current, ai, weather, gps, saveFile, say, get farm() { return farm; }, get cloud() { return hasCloud; }, client: sb, config: C };
})();
