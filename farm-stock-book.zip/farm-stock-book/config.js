/* Farm Stock Book — settings. This is the only file you need to edit.
   Leave supabaseUrl and supabaseAnonKey empty to run in DEMO mode
   (everything saved on that one phone, no login). */
window.FSB_CONFIG = {
  appName: "Farm Stock Book",

  // From Supabase → Project Settings → API. The anon key is safe to put here.
  supabaseUrl: "",
  supabaseAnonKey: "",

  // Weather. Leave empty to use Open-Meteo's free service (non-commercial use).
  // When you charge farmers, buy an Open-Meteo API plan and put the key here.
  openMeteoKey: "",

  // Map tiles. OpenStreetMap's own tiles are fine for testing only.
  // For a live service use a tile provider with a key (e.g. MapTiler, Stadia Maps).
  mapTiles: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
  mapAttribution: "© OpenStreetMap contributors",
};
