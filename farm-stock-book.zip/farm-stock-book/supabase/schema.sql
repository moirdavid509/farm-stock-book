-- Farm Stock Book — database setup for Supabase (PIN login version).
-- Paste all of this into Supabase → SQL Editor → New query, then press Run. Run it once.
--
-- How login works:
--   Each farm has a farm code (6 letters/numbers). On a new phone you type the farm code,
--   tap your name, and type your 4-number PIN. The farmer (owner) adds people and resets PINs.
--   PINs are stored scrambled (bcrypt) in a hidden table. Wrong tries lock the person out:
--   5 wrong = locked for 15 minutes, 10 wrong in a row = locked until the farmer resets the PIN.
--
-- Tables:
--   farms           one row per farm, with its farm code
--   members         people on each farm (name, owner or worker)
--   member_secrets  hidden: scrambled PINs and wrong-try counters (no app access at all)
--   login_attempts  hidden: log of tries, to slow down guessing
--   docs            every record in the app (stock, spray records, SQC sheets...) as JSON

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------- farm codes: easy to read out, no 0/O or 1/I mix-ups ----------
create or replace function public.gen_farm_code() returns text
language plpgsql volatile security definer set search_path = public, extensions as $$
declare a text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; b bytea := gen_random_bytes(6); c text := ''; i int;
begin
  for i in 0..5 loop c := c || substr(a, (get_byte(b, i) % 32) + 1, 1); end loop;
  return c;
end $$;

create table if not exists public.farms (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  join_code  text not null unique default public.gen_farm_code(),
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  farm_id      uuid not null references public.farms on delete cascade,
  user_id      uuid not null references auth.users on delete cascade,
  role         text not null default 'worker' check (role in ('owner','worker')),
  display_name text not null,
  active       boolean not null default true,
  created_at   timestamptz not null default now(),
  primary key (farm_id, user_id)
);

create table if not exists public.member_secrets (
  user_id      uuid primary key references auth.users on delete cascade,
  pin_hash     text not null,
  failed       int not null default 0,
  locked_until timestamptz,
  blocked      boolean not null default false,
  pin_set_at   timestamptz not null default now()
);

create table if not exists public.login_attempts (
  id      bigserial primary key,
  at      timestamptz not null default now(),
  farm_id uuid,
  ip      text,
  ok      boolean not null
);
create index if not exists login_attempts_recent on public.login_attempts (at);

create table if not exists public.docs (
  farm_id    uuid not null references public.farms on delete cascade,
  coll       text not null,
  id         text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid default auth.uid(),
  primary key (farm_id, coll, id)
);
-- Lets deletes reach other phones in real time.
alter table public.docs replica identity full;

create table if not exists public.scan_log (
  id bigserial primary key,
  user_id uuid default auth.uid(),
  at timestamptz not null default now(),
  ok boolean not null default true
);

-- ---------- security ----------
alter table public.farms          enable row level security;
alter table public.members        enable row level security;
alter table public.member_secrets enable row level security;  -- no policies: the app can never read it
alter table public.login_attempts enable row level security;  -- no policies
alter table public.docs           enable row level security;
alter table public.scan_log       enable row level security;  -- no policies

create or replace function public.is_member(f uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.members where farm_id = f and user_id = auth.uid() and active);
$$;

drop policy if exists "members read farm" on public.farms;
create policy "members read farm" on public.farms for select using (public.is_member(id));

drop policy if exists "members read members" on public.members;
create policy "members read members" on public.members for select using (public.is_member(farm_id));

drop policy if exists "members use docs" on public.docs;
create policy "members use docs" on public.docs for all
  using (public.is_member(farm_id)) with check (public.is_member(farm_id));

-- ---------- PIN rules ----------
-- Refuses PINs that are easy to guess: 0000, 1111, 1234, 4321, 1212, 2580 and so on.
create or replace function public.pin_is_ok(p text) returns boolean
language plpgsql immutable as $$
declare d int[]; i int; up boolean := true; down boolean := true;
begin
  if p is null or p !~ '^[0-9]{4}$' then return false; end if;
  if p in ('1212','2580','0852','1122','1313','6969','1004','2000','1010','2020','2121','1001','0101') then return false; end if;
  d := array[substr(p,1,1)::int, substr(p,2,1)::int, substr(p,3,1)::int, substr(p,4,1)::int];
  if d[1]=d[2] and d[2]=d[3] and d[3]=d[4] then return false; end if;
  for i in 1..3 loop
    if d[i+1] <> (d[i] + 1) % 10 then up := false; end if;
    if d[i+1] <> (d[i] + 9) % 10 then down := false; end if;
  end loop;
  return not (up or down);
end $$;

create or replace function public.pin_set(p_user uuid, p_pin text) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.pin_is_ok(p_pin) then raise exception 'weak_pin'; end if;
  insert into public.member_secrets (user_id, pin_hash) values (p_user, crypt(p_pin, gen_salt('bf', 8)))
  on conflict (user_id) do update set pin_hash = excluded.pin_hash, failed = 0, locked_until = null, blocked = false, pin_set_at = now();
end $$;

-- Checks a PIN. Returns: ok | wrong:<tries left before lock> | locked | blocked | slow_down
create or replace function public.pin_check(p_user uuid, p_pin text, p_ip text) returns text
language plpgsql security definer set search_path = public, extensions as $$
declare s public.member_secrets; f uuid; n int;
begin
  select farm_id into f from public.members where user_id = p_user and active limit 1;
  if f is null then return 'blocked'; end if;
  -- Whole farm or one phone guessing a lot: slow everything down for an hour.
  select count(*) into n from public.login_attempts where farm_id = f and not ok and at > now() - interval '1 hour';
  if n >= 30 then return 'slow_down'; end if;
  select count(*) into n from public.login_attempts where ip = p_ip and not ok and at > now() - interval '1 hour';
  if n >= 30 then return 'slow_down'; end if;

  select * into s from public.member_secrets where user_id = p_user for update;
  if not found then return 'blocked'; end if;
  if s.blocked then return 'blocked'; end if;
  if s.locked_until is not null and s.locked_until > now() then return 'locked'; end if;

  if crypt(coalesce(p_pin,''), s.pin_hash) = s.pin_hash then
    update public.member_secrets set failed = 0, locked_until = null where user_id = p_user;
    insert into public.login_attempts (farm_id, ip, ok) values (f, p_ip, true);
    return 'ok';
  end if;

  insert into public.login_attempts (farm_id, ip, ok) values (f, p_ip, false);
  update public.member_secrets set failed = failed + 1,
    blocked = (failed + 1 >= 10),
    locked_until = case when (failed + 1) % 5 = 0 then now() + interval '15 minutes' else locked_until end
  where user_id = p_user returning * into s;
  if s.blocked then return 'blocked'; end if;
  if s.locked_until is not null and s.locked_until > now() then return 'locked'; end if;
  return 'wrong:' || (5 - (s.failed % 5));
end $$;

-- Farm code → farm name and the people on it. Too many wrong codes from one phone: refuse for an hour.
create or replace function public.farm_people(p_code text, p_ip text)
returns table (farm_id uuid, farm_name text, user_id uuid, display_name text, role text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare n int; f public.farms;
begin
  select count(*) into n from public.login_attempts where ip = p_ip and farm_id is null and not ok and at > now() - interval '1 hour';
  if n >= 20 then raise exception 'slow_down'; end if;
  select * into f from public.farms where join_code = upper(regexp_replace(coalesce(p_code,''), '\s', '', 'g'));
  if not found then
    insert into public.login_attempts (farm_id, ip, ok) values (null, p_ip, false);
    return;
  end if;
  return query select f.id, f.name, m.user_id, m.display_name, m.role
    from public.members m where m.farm_id = f.id and m.active order by m.role = 'worker', m.display_name;
end $$;

-- Owner makes a new farm code (e.g. after a worker leaves).
create or replace function public.new_farm_code(p_farm uuid) returns text
language plpgsql security definer set search_path = public, extensions as $$
declare c text;
begin
  loop
    c := public.gen_farm_code();
    exit when not exists (select 1 from public.farms where join_code = c);
  end loop;
  update public.farms set join_code = c where id = p_farm;
  return c;
end $$;

-- Tidy the try log after 30 days.
create or replace function public.prune_login_attempts() returns void
language sql security definer set search_path = public as $$
  delete from public.login_attempts where at < now() - interval '30 days';
$$;

-- Only the server function (service role) may use these.
revoke all on function public.pin_set(uuid, text), public.pin_check(uuid, text, text), public.farm_people(text, text),
  public.new_farm_code(uuid), public.prune_login_attempts(), public.gen_farm_code() from public, anon, authenticated;
grant execute on function public.pin_set(uuid, text), public.pin_check(uuid, text, text), public.farm_people(text, text),
  public.new_farm_code(uuid), public.prune_login_attempts(), public.gen_farm_code() to service_role;

-- ---------- live updates between phones ----------
do $$ begin
  alter publication supabase_realtime add table public.docs;
exception when duplicate_object then null; when undefined_object then null; end $$;
