// Farm Stock Book — "pin-auth" server function (Supabase Edge Function).
// Login with farm code + name + 4-number PIN, starting a farm, and the farmer managing people.
// Each person is a Supabase user behind the scenes; nobody ever sees or types an email.
//
// Optional secret (Supabase → Edge Functions → Secrets):
//   SIGNUP_CODE   if set, starting a NEW farm needs this code. Use it so only your customers can sign up.
import { createClient } from "jsr:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
// Business answers (wrong PIN etc.) come back as 200 with { error }, so the app can show friendly words.
const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const fail = (error: string, extra: Record<string, unknown> = {}) => reply({ error, ...extra });

const URL_ = Deno.env.get("SUPABASE_URL")!;
const admin = createClient(URL_, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const anon = createClient(URL_, Deno.env.get("SUPABASE_ANON_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const EMAIL_DOMAIN = "farmstockbook.invalid"; // never receives mail; just a unique login name per person

const cleanName = (s: unknown) => String(s ?? "").replace(/\s+/g, " ").trim().slice(0, 40);
const isPin = (s: unknown) => /^[0-9]{4}$/.test(String(s ?? ""));

async function pinOk(pin: string) {
  const { data } = await admin.rpc("pin_is_ok", { p: pin });
  return data === true;
}

// Make a real login session for a person without email: create a one-time token and use it straight away.
async function mintSession(userId: string) {
  const { data: u, error: e1 } = await admin.auth.admin.getUserById(userId);
  if (e1 || !u?.user?.email) throw new Error("No such person");
  const { data: link, error: e2 } = await admin.auth.admin.generateLink({ type: "magiclink", email: u.user.email });
  if (e2) throw e2;
  const { data: s, error: e3 } = await anon.auth.verifyOtp({ type: "magiclink", token_hash: link.properties.hashed_token });
  if (e3 || !s.session) throw e3 || new Error("No session");
  return { access_token: s.session.access_token, refresh_token: s.session.refresh_token };
}

async function newPerson(farmId: string, name: string, pin: string, role: "owner" | "worker") {
  const { data, error } = await admin.auth.admin.createUser({
    email: `p-${crypto.randomUUID()}@${EMAIL_DOMAIN}`,
    email_confirm: true,
    password: crypto.randomUUID() + crypto.randomUUID(), // never used
    user_metadata: { display_name: name },
  });
  if (error || !data.user) throw error || new Error("Could not add person");
  const uid = data.user.id;
  const m = await admin.from("members").insert({ farm_id: farmId, user_id: uid, role, display_name: name });
  if (m.error) { await admin.auth.admin.deleteUser(uid); throw m.error; }
  const p = await admin.rpc("pin_set", { p_user: uid, p_pin: pin });
  if (p.error) { await admin.auth.admin.deleteUser(uid); throw p.error; }
  return uid;
}

const farmOut = (f: { id: string; name: string; join_code: string }, role: string, name: string) =>
  ({ id: f.id, name: f.name, join_code: role === "owner" ? f.join_code : f.join_code, role, me: name });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return reply({ error: "Use POST" }, 405);
  const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "unknown";
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return reply({ error: "Bad request" }, 400); }
  const action = String(b.action || "");

  try {
    // ---------- no login needed ----------
    if (action === "people") {
      const { data, error } = await admin.rpc("farm_people", { p_code: String(b.code || ""), p_ip: ip });
      if (error) return fail(/slow_down/.test(error.message) ? "slow_down" : "server");
      if (!data?.length) return fail("no_farm");
      return reply({ farm: { name: data[0].farm_name }, people: data.map((r: Record<string, string>) => ({ id: r.user_id, name: r.display_name, role: r.role })) });
    }

    if (action === "login") {
      const { data: ppl, error } = await admin.rpc("farm_people", { p_code: String(b.code || ""), p_ip: ip });
      if (error) return fail(/slow_down/.test(error.message) ? "slow_down" : "server");
      const me = (ppl || []).find((r: Record<string, string>) => r.user_id === b.userId);
      if (!me) return fail("no_farm");
      const { data: res } = await admin.rpc("pin_check", { p_user: me.user_id, p_pin: String(b.pin || ""), p_ip: ip });
      if (res !== "ok") {
        const [kind, left] = String(res || "server").split(":");
        return fail(kind, left ? { left: Number(left) } : {});
      }
      const { data: f } = await admin.from("farms").select("id,name,join_code").eq("id", me.farm_id).single();
      return reply({ session: await mintSession(me.user_id), farm: farmOut(f!, me.role, me.display_name) });
    }

    if (action === "create_farm") {
      const need = Deno.env.get("SIGNUP_CODE");
      if (need && String(b.signupCode || "").trim().toUpperCase() !== need.trim().toUpperCase()) return fail("signup_code");
      const farmName = cleanName(b.farmName), name = cleanName(b.name), pin = String(b.pin || "");
      if (!farmName || !name) return fail("missing");
      if (!isPin(pin) || !(await pinOk(pin))) return fail("weak_pin");
      const { data: f, error } = await admin.from("farms").insert({ name: farmName }).select("id,name,join_code").single();
      if (error || !f) throw error;
      let uid: string;
      try { uid = await newPerson(f.id, name, pin, "owner"); }
      catch (e) { await admin.from("farms").delete().eq("id", f.id); throw e; }
      return reply({ session: await mintSession(uid), farm: farmOut(f, "owner", name) });
    }

    // ---------- logged-in person ----------
    const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const { data: who } = await admin.auth.getUser(token);
    if (!who?.user) return fail("session_expired");
    const { data: mine } = await admin.from("members").select("farm_id,role,display_name").eq("user_id", who.user.id).eq("active", true).maybeSingle();
    if (!mine) return fail("not_member");
    const ownerOnly = () => mine.role !== "owner";
    const sameFarm = async (uid: unknown) => {
      const { data } = await admin.from("members").select("user_id,role,display_name").eq("farm_id", mine.farm_id).eq("user_id", String(uid)).eq("active", true).maybeSingle();
      return data;
    };

    // Site tablet: check someone's PIN on this farm without logging the tablet in as them.
    if (action === "verify_pin") {
      const p = await sameFarm(b.userId); if (!p) return fail("not_found");
      const { data: res } = await admin.rpc("pin_check", { p_user: p.user_id, p_pin: String(b.pin || ""), p_ip: ip });
      if (res !== "ok") { const [kind, left] = String(res).split(":"); return fail(kind, left ? { left: Number(left) } : {}); }
      return reply({ ok: true, person: { id: p.user_id, name: p.display_name, role: p.role } });
    }

    // Change a PIN. Needs the person's current PIN. On a site tablet, userId says whose PIN it is.
    if (action === "change_pin") {
      const target = b.userId ? await sameFarm(b.userId) : { user_id: who.user.id };
      if (!target) return fail("not_found");
      const { data: res } = await admin.rpc("pin_check", { p_user: target.user_id, p_pin: String(b.oldPin || ""), p_ip: ip });
      if (res !== "ok") { const [kind, left] = String(res).split(":"); return fail(kind, left ? { left: Number(left) } : {}); }
      const pin = String(b.newPin || "");
      if (!isPin(pin) || !(await pinOk(pin))) return fail("weak_pin");
      const { error } = await admin.rpc("pin_set", { p_user: target.user_id, p_pin: pin });
      if (error) throw error;
      return reply({ ok: true });
    }

    if (action === "list_people") {
      const { data } = await admin.from("members").select("user_id,role,display_name").eq("farm_id", mine.farm_id).eq("active", true).order("display_name");
      const ids = (data || []).map((m) => m.user_id);
      const { data: sec } = ids.length ? await admin.from("member_secrets").select("user_id,blocked,locked_until,pin_set_at").in("user_id", ids) : { data: [] };
      const st = new Map((sec || []).map((s) => [s.user_id, s.blocked ? "blocked" : s.locked_until && new Date(s.locked_until) > new Date() ? "locked" : "ok"]));
      const set = new Map((sec || []).map((s) => [s.user_id, s.pin_set_at]));
      // pinSetAt lets a site tablet notice a changed PIN and forget its offline copy of the old one.
      return reply({ people: (data || []).map((m) => ({ id: m.user_id, name: m.display_name, role: m.role, status: st.get(m.user_id) || "ok", pinSetAt: set.get(m.user_id) || "" })) });
    }

    if (ownerOnly()) return fail("owner_only");

    if (action === "add_person") {
      const name = cleanName(b.name), pin = String(b.pin || "");
      if (!name) return fail("missing");
      if (!isPin(pin) || !(await pinOk(pin))) return fail("weak_pin");
      const { count } = await admin.from("members").select("user_id", { count: "exact", head: true }).eq("farm_id", mine.farm_id).eq("active", true).ilike("display_name", name);
      if ((count ?? 0) > 0) return fail("same_name");
      const role = b.role === "owner" ? "owner" : "worker";
      const id = await newPerson(mine.farm_id, name, pin, role);
      return reply({ ok: true, id });
    }

    if (action === "reset_pin") {
      const p = await sameFarm(b.userId); if (!p) return fail("not_found");
      const pin = String(b.pin || "");
      if (!isPin(pin) || !(await pinOk(pin))) return fail("weak_pin");
      const { error } = await admin.rpc("pin_set", { p_user: p.user_id, p_pin: pin });
      if (error) throw error;
      return reply({ ok: true });
    }

    if (action === "remove_person") {
      const p = await sameFarm(b.userId); if (!p) return fail("not_found");
      if (p.user_id === who.user.id) return fail("not_self");
      await admin.from("members").update({ active: false }).eq("farm_id", mine.farm_id).eq("user_id", p.user_id);
      await admin.auth.admin.updateUserById(p.user_id, { ban_duration: "876000h" }); // logs them out everywhere
      return reply({ ok: true });
    }

    if (action === "new_code") {
      const { data, error } = await admin.rpc("new_farm_code", { p_farm: mine.farm_id });
      if (error) throw error;
      return reply({ ok: true, code: data });
    }

    return reply({ error: "Unknown action" }, 400);
  } catch (e) {
    console.error(action, e);
    return fail("server");
  }
});
