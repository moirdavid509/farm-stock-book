// Farm Stock Book — "scan" server function (Supabase Edge Function).
// Reads a photo (stock shelves, whiteboard, agronomist's sheet) with Claude and returns the text.
// The Anthropic API key stays on the server; phones never see it.
//
// Secrets to set (Supabase → Edge Functions → Secrets):
//   ANTHROPIC_API_KEY   your key from console.anthropic.com   (required)
//   ANTHROPIC_MODEL     optional, defaults to claude-sonnet-5-5
//   SCANS_PER_DAY       optional, per person, defaults to 40
import { createClient } from "jsr:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return reply({ error: "Use POST" }, 405);

  // Who is asking? Only logged-in farm users may scan.
  const url = Deno.env.get("SUPABASE_URL")!;
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const admin = createClient(url, service);
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: who } = await admin.auth.getUser(token);
  if (!who?.user) return reply({ error: "Please log in again.", code: "session_expired" }, 401);

  // Simple daily limit per person, to keep costs predictable.
  const limit = Number(Deno.env.get("SCANS_PER_DAY") || 40);
  const since = new Date(Date.now() - 24 * 3600e3).toISOString();
  const { count } = await admin.from("scan_log").select("id", { count: "exact", head: true }).eq("user_id", who.user.id).gte("at", since);
  if ((count ?? 0) >= limit) return reply({ error: "Daily photo limit reached. Try again tomorrow.", code: "rate_limited" }, 429);

  let body: { prompt?: string; image?: string | null; mediaType?: string };
  try { body = await req.json(); } catch { return reply({ error: "Bad request" }, 400); }
  const prompt = String(body.prompt || "").slice(0, 20000);
  if (!prompt) return reply({ error: "No prompt" }, 400);
  if (body.image && body.image.length > 8_000_000) return reply({ error: "Photo too large", code: "image_rejected" }, 413);

  const key = Deno.env.get("ANTHROPIC_API_KEY");
  if (!key) return reply({ error: "Photo reading isn't set up on the server yet." }, 500);

  const content: unknown[] = [];
  if (body.image) content.push({ type: "image", source: { type: "base64", media_type: body.mediaType || "image/jpeg", data: body.image } });
  content.push({ type: "text", text: prompt + "\n\nReply with only the JSON, no other text." });

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: Deno.env.get("ANTHROPIC_MODEL") || "claude-sonnet-5-5",
      max_tokens: 4000,
      messages: [{ role: "user", content }],
    }),
  });
  const j = await r.json().catch(() => ({}));
  await admin.from("scan_log").insert({ user_id: who.user.id, ok: r.ok });
  if (!r.ok) return reply({ error: j?.error?.message || "Photo reading failed", code: r.status === 429 ? "rate_limited" : "upstream_error" }, 502);
  const text = (j.content || []).filter((c: { type: string }) => c.type === "text").map((c: { text: string }) => c.text).join("");
  return reply({ text });
});
