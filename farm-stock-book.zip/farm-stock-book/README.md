# Farm Stock Book

A phone and tablet app for Scottish farms: stock in and out by voice or photo, spray planning against stock, spray weather, GPS field tracking, and the full SQC Farm Record Book with Excel export.

It is a **web app (PWA)**. Farmers open a link once, tap **Add to Home Screen**, and from then on it opens like a normal app. It works with no signal and syncs when signal comes back. No app store and no Claude account needed.

---

## What's in this folder

| File / folder | What it is |
|---|---|
| `index.html` | The app itself |
| `config.js` | **The only file you edit.** Your database keys and options |
| `js/store.js` | Saves records on the phone, then syncs them online |
| `js/platform.js` | PIN login, farm codes, weather, GPS, photo reading, saving files |
| `sw.js`, `manifest.webmanifest`, `icons/` | Makes it installable and work offline |
| `vendor/`, `fonts/` | Libraries and fonts, bundled so nothing depends on outside sites |
| `supabase/schema.sql` | Sets up the database (run once) |
| `supabase/functions/pin-auth/` | Server code for PIN login and managing people |
| `supabase/functions/scan/` | Server code for reading photos |

---

## Step 1 — Try it now (10 minutes, free)

With `config.js` left empty, the app runs in **demo mode**: everything is saved on that one phone, no login.

1. Go to **app.netlify.com/drop** (free account).
2. Drag this whole `farm-stock-book` folder onto the page.
3. Netlify gives you a web address like `https://something.netlify.app`. Open it on your phone.
4. Tap **Settings → Load the example farm** to see it working with the 00477 plan and your fields.
5. On the phone: **Share → Add to Home Screen** (iPhone) or **⋮ → Install app** (Android).

GPS, the microphone and offline mode need `https://`, which Netlify gives you automatically.

---

## Step 2 — Go live with logins and shared records (about 1 hour)

This lets the farmer and workers share one set of records across phones.

### 2a. Make the database
1. Sign up at **supabase.com** (free to start). Make a new project. Pick the **London** region.
2. Open **SQL Editor → New query**. Paste everything from `supabase/schema.sql`. Press **Run**.

### 2b. Turn off public sign-ups
Logins are made by the app's own server function, not by people signing up themselves.
1. **Authentication → Sign In / Providers**: turn **off** "Allow new users to sign up".
   (The server function can still add people. This just stops anyone making accounts directly.)
2. No email setup is needed. Nobody types or receives an email.

### 2c. Install the login function
Install the Supabase command line tool (see supabase.com/docs/guides/cli), then in this folder run:
```
supabase login
supabase link --project-ref YOUR-PROJECT-REF
supabase functions deploy pin-auth
```
Optional: only let your customers start new farms. Pick a sign-up code and set it:
```
supabase secrets set SIGNUP_CODE=HIGHLAND25
```
Give that code to each farm you sign up. Without it, anyone with the app's address could start a farm.

### 2d. Connect the app
1. **Project Settings → API**. Copy the **Project URL** and the **anon public** key.
2. Open `config.js` and paste them in:
   ```js
   supabaseUrl: "https://xxxx.supabase.co",
   supabaseAnonKey: "eyJhbGciOi...",
   ```
3. Upload the folder to Netlify again (drag and drop onto your site's **Deploys** page).

### How login works for farmers
- **The farmer, first time:** taps **Setting up a new farm?**, types the farm name and their own name, and picks a 4-number PIN (twice). The app shows the **farm code**, 6 letters and numbers like `K7P2QX`.
- **Adding workers:** the farmer goes to **Settings → People on this farm → Add a person**, types the worker's name, and picks a PIN with them.
- **A worker's phone, first time:** type the farm code, tap your name, type your PIN. After that the phone stays logged in.
- **Shared tablet in the office:** **Settings → Switch person** goes back to the list of names.
- **Forgotten PIN:** the farmer taps the person's name in **People** and gives them a new PIN.
- **Someone leaves:** the farmer taps their name and **Remove**. They're logged out on every phone at once. Their past records stay. For extra safety, tap **Make a new farm code**.

### How safe is a 4-number PIN?
On its own, a 4-number PIN only has 10,000 combinations, so the server guards it:
- **5 wrong tries:** that person is locked for 15 minutes.
- **10 wrong tries in a row:** locked until the farmer gives them a new PIN.
- **A phone making 30 wrong guesses in an hour:** it's stopped for an hour. The same goes for a farm getting 30 wrong guesses in an hour.
- **Wrong farm codes:** a phone typing 20 in an hour is stopped for an hour.
- **Easy PINs** like 1234, 1111, 4321, 1212 or 2580 are refused.
- **Stored scrambled:** PINs are kept as bcrypt hashes in a table the app itself can never read.

It's the same idea as a bank card PIN. A thief would also need the farm code and to guess the right name, and they'd be locked out after a few tries.

### A shared tablet kept on site
Use the same app on an iPad or Android tablet as well as phones. Everything syncs between them.

**Setting it up** (the farmer does this once, on the tablet):
1. Open the app's address on the tablet, **Add to Home Screen**, and log in as yourself (farm code, your name, your PIN).
2. **Settings → Make this a shared site tablet**. Pick how long before it locks itself (5 minutes is a good start).

**Using it:**
- The tablet opens on **Who are you?** Tap your name, type your PIN, and you're in. Records are signed with your name.
- It locks itself after the set time with nobody using it, so the next person can't record under your name. Tap **🔒 Lock** to lock it straight away.
- It never locks in the middle of **Spraying now**.
- **No signal in the shed?** Anyone who has unlocked the tablet once with signal can unlock it with no signal. The tablet keeps a scrambled copy of their PIN for this. Someone who has never used it needs signal the first time.
- Wrong PINs lock people out on the tablet too, even with no signal: 5 wrong tries locks for 15 minutes, 10 locks until there's signal.
- **PIN changes:** if the farmer resets someone's PIN or removes them, the tablet forgets the old one the next time it has signal. A removed worker can't unlock it once it has had signal since they were removed.
- **Owner-only settings:** People, the farm code and turning off tablet mode only appear when the farmer is the one unlocked.

**Practical tips:**
- **Lock the tablet to this one app:** **Guided Access** on iPad (Settings → Accessibility → Guided Access), or **App pinning** on Android (Settings → Security).
- Keep it on charge, in a rugged case, mounted near the chemical store door.
- Yard Wi-Fi helps, but isn't essential. Records sync when signal comes back.
- Behind the scenes the tablet stays logged in to the farm as the farmer who set it up, so keep it on the farm.

---

## Step 3 — Turn on photo reading (optional)

Scanning the store shelves, the whiteboard or the agronomist's sheet uses Claude through the Anthropic API. The key stays on your server; phones never see it.

1. Get an API key at **console.anthropic.com** and add credit.
2. In this folder run (you installed the Supabase tool in Step 2c):
   ```
   supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
   supabase functions deploy scan
   ```
3. Optional secrets: `ANTHROPIC_MODEL` (defaults to `claude-sonnet-5-5`), `SCANS_PER_DAY` (per person, defaults to 40).

Each scan costs roughly a few pence. The `scan_log` table records every scan so you can see usage per person. Without this step the app still works; the Scan buttons just say photo reading isn't switched on.

---

## Before charging farmers

- **Weather**: the free Open-Meteo service is for non-commercial use. Buy an Open-Meteo API plan and put the key in `config.js` → `openMeteoKey`.
- **Maps**: OpenStreetMap's own map tiles are for light use only. Sign up with a tile provider (e.g. MapTiler, Stadia Maps) and put their URL in `config.js` → `mapTiles`.
- **Sign-ups**: set a `SIGNUP_CODE` (Step 2c) so only paying farms can start a farm.
- **Data protection**: register with the ICO (ico.org.uk), and write a short privacy notice saying what you store (people's names, farm records, GPS tracks) and where (Supabase, London region).
- **SQC**: the record sheets follow the SQC Farm Record Book. Ask SQC to look over the Excel export, and whether they would recognise or recommend it. That's your strongest selling point.
- **Backups**: Supabase's paid plan includes daily backups. Farmers can also tap **Settings → Save a backup file**.

## Rough running costs

| Item | Cost |
|---|---|
| Web address (e.g. farmstockbook.co.uk) | about £10 a year |
| Hosting (Netlify / Cloudflare Pages) | free to start |
| Database (Supabase) | free to start, then about £20 a month |
| Photo reading (Anthropic API) | a few pence per scan |
| Weather API plan (commercial) | check open-meteo.com pricing |
| ICO registration | about £40 a year |

Prices change, so check each one before you set your own price.

---

## Updating the app

1. Change the files.
2. In `sw.js`, change `VERSION = "fsb-v1"` to `"fsb-v2"` (and so on each time). This tells phones to fetch the new version.
3. Upload the folder again.

## Things to know

- **GPS tracking needs the app open on screen.** The app keeps the screen awake while "Spraying now" is running. A web app can't track in the background with the screen locked; that needs a native app (the next step if this takes off).
- **Voice** uses the phone's built-in speech recognition. On iPhone this needs signal. The keyboard's microphone key always works as a backup.
- **Storage on the phone**: records are kept in the browser's storage, which comfortably holds several years of records for a normal farm. If a farm has tens of thousands of records, move `js/store.js` to IndexedDB.
- **Two people changing the same thing at the same moment** (especially both offline): the last one saved wins. If two phones take the same product out of stock while both have no signal, one of those stock changes can be lost, though both log entries are kept. A regular stock count (or a Scan) puts it right.
- **Field spots for GPS**: on the Spray tab, open **Your fields**, pick a field, stand in it and tap **Save this field's spot**. After that the app can tell which field you're in.
