/* Farm Stock Book — offline support.
   Keeps the app itself on the phone so it opens with no signal.
   Records are stored separately by the app and sync when signal returns.
   Change VERSION whenever you upload new app files, so phones pick up the update. */
const VERSION = "fsb-v3";
const SHELL = [
  "./", "index.html", "config.js", "manifest.webmanifest",
  "js/store.js", "js/platform.js",
  "vendor/supabase.js", "vendor/591.supabase.js", "vendor/xlsx.mini.min.js",
  "vendor/leaflet/leaflet.js", "vendor/leaflet/leaflet.css",
  "fonts/atkinson-hyperlegible-latin-400-normal.woff2", "fonts/atkinson-hyperlegible-latin-700-normal.woff2",
  "fonts/zilla-slab-latin-600-normal.woff2", "fonts/zilla-slab-latin-700-normal.woff2",
  "icons/icon-192.png", "icons/icon-512.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET") return;
  // Our own app files: use the network when there is signal (so updates arrive), fall back to the saved copy.
  if (url.origin === self.location.origin) {
    e.respondWith(
      fetch(e.request).then((r) => { if (r.ok) { const c = r.clone(); caches.open(VERSION).then((ca) => ca.put(e.request, c)); } return r; })
        .catch(() => caches.match(e.request, { ignoreSearch: true }).then((m) => m || caches.match("index.html")))
    );
    return;
  }
  // Map tiles: keep a copy of tiles already seen, so the farm map works with poor signal.
  if (/tile/.test(url.hostname)) {
    e.respondWith(caches.open(VERSION + "-tiles").then((c) => c.match(e.request).then((m) => m || fetch(e.request).then((r) => { if (r.ok) c.put(e.request, r.clone()); return r; }))));
  }
  // Everything else (database, weather, photo reading) goes straight to the network.
});
